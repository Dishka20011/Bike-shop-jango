from django.contrib import admin
from .models import *
# Register your models here.



class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', ]
admin.site.register(Category, CategoryAdmin)


class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'description','price','new_price','brand','category_id']
admin.site.register(Product, ProductAdmin)   

class ProductImageAdmin(admin.ModelAdmin):
    list_display = ['product_id', 'image']    
admin.site.register(ProductImage,ProductImageAdmin)