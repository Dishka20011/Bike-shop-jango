from django.urls import path

from . import views

urlpatterns = [
    path('', views.bicycles, name='bicycles'),
    path('bicycles.html', views.bicycles),
    path('single.html/<int:product_id>', views.single, name='single'),
    path('addToBasket.html/<int:product_id>', views.addToBasket, name='addToBasket'),
    path('basket.html', views.basket),
    path('admin.html', views.admin),
    path('reg.html', views.reg),
    path('signup', views.signup, name='signup'),
    path('about.html', views.about, name='about'),
]
