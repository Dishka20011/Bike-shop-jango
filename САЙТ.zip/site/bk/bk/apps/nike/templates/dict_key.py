from django.template.defaultfilters import register

def get_item(d, k):
    '''Returns the given key from a dictionary.'''
    return d[k]

register.filter('get_item', get_item)