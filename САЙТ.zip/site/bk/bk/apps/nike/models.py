from django.db import models


# Create your models here.
class ProductImage(models.Model):
    product_id = models.IntegerField()
    image = models.CharField(max_length=255)
    




class Product(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    price = models.IntegerField()
    new_price = models.IntegerField()
    brand = models.CharField(max_length=255)
    category_id = models.IntegerField()
    def str(self):
        return self.name




class Category(models.Model):
    name = models.CharField(max_length=255)


class Order(models.Model):
    product_id = models.IntegerField()
    quantity = models.IntegerField()
    user_id = models.IntegerField()


class Cart(models.Model):
    status = models.CharField(max_length=255)
    user_id = models.IntegerField()
    total_price = models.IntegerField()


class User(models.Model):
    name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)


class CartProduct(models.Model):
    product_id = models.IntegerField()
    cart_id = models.IntegerField()
    quantity = models.IntegerField()
