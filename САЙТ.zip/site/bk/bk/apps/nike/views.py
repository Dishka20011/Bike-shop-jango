from django.shortcuts import render
from django.http import HttpResponse
from .models import Product, ProductImage


def bicycles(request):
    mountain_bikes = Product.objects.filter(category_id=1)
    single_speed_bikes = Product.objects.filter(category_id=2)
    road_bikes = Product.objects.filter(category_id=3)

    for bike in list(mountain_bikes) + list(single_speed_bikes) + list(road_bikes):
        bike.image = 'images/' + ProductImage.objects.get(product_id=bike.id).image

    args = {
        'mountain_bikes': mountain_bikes,
        'single_speed_bikes': single_speed_bikes,
        'road_bikes': road_bikes
    }
    return render(request, 'bicycles.html', args)


def single(request, product_id):
    return render(request, 'single.html')


def addToBasket(request, product_id):
    request.session.modified = True
    if request.session.has_key('basket'):
        products = request.session['basket']
        products[str(product_id)] = products.get(str(product_id), 0) + 1
        request.session['basket'] = products
    else:
        request.session['basket'] = {product_id: 1}
    return render(request, 'addToBasket.html')


def basket(request):
    products = Product.objects.filter(id__in=request.session['basket'])
    counts = request.session['basket']

    total_price = 0
    for bike in products:
        bike.image = 'images/' + ProductImage.objects.get(product_id=bike.id).image
        total_price += bike.price

    
    if request.method =="POST" and 'delete' in request.POST : 
       request.session['basket'] = {}
       
       request.session.modified = True

    return render(request, 'basket.html', {'products': products, 'total_price': total_price})


def admin(request):
    return render(request, 'admin.html')

def about(request):
    return render(request, 'about.html')

def reg(request):
    return render(request, 'reg.html')

def signup(request):
    
 
    
    
    
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        
        if form.is_valid () :
            form.save()
            username = form.cleaned_data.get('username')
            
            raw_password = form.cleaned_data.get('password1')
            response = redirect('/')
            return response
            
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})
